#include <iostream>
#include <string>
#include <stdexcept>
#include <cassert>
#include <memory>
#include <map>
#include "node.h"
#include "lexer.h"
#include "treeprint.h"

////////////////////////////////////////////////////////////////////////
// Parser implementation
////////////////////////////////////////////////////////////////////////

namespace {

enum Direction { LEFT, RIGHT };

// map of infix operators to their precedence
std::map<int, int> OP_PREC = {
  { OP_ASSIGN, 0 },
  { OP_PLUS, 1 },
  { OP_MINUS, 1 },
  { OP_TIMES, 2 },
  { OP_DIVIDE, 2 },
  { OP_EXP, 3 },
};

// map of infix operators to their associativity
std::map<int, Direction> OP_ASSOC = {
  { OP_ASSIGN, RIGHT },
  { OP_PLUS, LEFT },
  { OP_MINUS, LEFT },
  { OP_TIMES, LEFT },
  { OP_DIVIDE, LEFT },
  { OP_EXP, RIGHT },
};

bool is_operator(Node *tok) {
  return OP_PREC.find(tok->get_tag()) != OP_PREC.end();
}

}

class Parser {
private:
  Lexer &m_lexer;

  Parser(const Parser &);
  Parser &operator=(const Parser &);

public:
  Parser(Lexer &lexer);
  ~Parser();

  Node *parse();

private:
  Node *parse_work(Node *lhs, int prec_level);
  Node *parse_primary();
  void expect_and_discard(int token_kind, const std::string &expected_lexeme);
};

Parser::Parser(Lexer &lexer)
  : m_lexer(lexer) {
}

Parser::~Parser() {
}

Node *Parser::parse() {
  // Parse one primary expression to get the ball rolling
  Node *lhs = parse_primary();

  // Parse the overall infix expression
  return parse_work(lhs, 0);
}

// This is the implementation of the precedence climbing algorithm!
Node *Parser::parse_work(Node *lhs, int prec_level) {
  // If the next token is not an infix operator, we're done
  Node *op = m_lexer.peek();
  if (op == nullptr || !is_operator(op))
    return lhs;

  assert(OP_PREC.find(op->get_tag()) != OP_PREC.end());
  assert(OP_ASSOC.find(op->get_tag()) != OP_ASSOC.end());

  // If the precedence level of the operator is lower than
  // the current precendence level, return (and let the operator
  // be handled by the caller)
  if (OP_PREC[op->get_tag()] < prec_level)
    return lhs;

  // Advance past the operator token
  m_lexer.next();

  // Get the next primary expression
  Node *rhs = parse_primary();

  // Look ahead to the next operator
  Node *next_op = m_lexer.peek();

  // If we've reached the end of input, or the next token isn't
  // an operator, apply the operator to the current lhs and rhs
  // trees, and we're done
  if (next_op == nullptr || !is_operator(next_op)) {
    op->append_kid(lhs);
    op->append_kid(rhs);
    return op;
  }

  assert(OP_PREC.find(next_op->get_tag()) != OP_PREC.end());
  assert(OP_ASSOC.find(next_op->get_tag()) != OP_ASSOC.end());

  // If the next operator has a higher precedence than the current level,
  // or is right-associative at the same level, parse the rhs
  // recursively at that level. The idea is to gather higher-precedence operators
  // (and right associative operators of the same precedence) into the
  // right hand part of the subtree rooted at the operator node.
  int next_op_prec = OP_PREC[next_op->get_tag()];
  Direction next_op_assoc = OP_ASSOC[next_op->get_tag()];
  if (next_op_prec > prec_level || (next_op_prec == prec_level && next_op_assoc == RIGHT)) {
    rhs = parse_work(rhs, next_op_prec);
  }

  // Now we can apply the operator to lhs and rhs
  op->append_kid(lhs);
  op->append_kid(rhs);

  // Continue trying to parse additional operators at the current precedence level
  return parse_work(op, prec_level);
}

Node *Parser::parse_primary() {
  Node *next_tok = m_lexer.peek();
  if (next_tok == nullptr)
    throw std::runtime_error("Unexpected end of input looking for primary expression");

  int next_tok_tag = next_tok->get_tag();

  // Identifiers and numbers are the most basic kinds of primary expression
  if (next_tok_tag == IDENT || next_tok_tag == NUMBER) {
    return m_lexer.next();
  }

  // Parenthesized subexpressions are also primary expressions
  if (next_tok_tag == LPAREN) {
    // consume and discard left paren
    expect_and_discard(LPAREN, "(");

    // parse the subexpression
    Node *sub_expr = parse();

    // consume and discard right paren
    expect_and_discard(RPAREN, ")");

    return sub_expr;
  }

  throw std::runtime_error("Unexpected token '" + next_tok->get_str() + "' looking for primary expression");
}

void Parser::expect_and_discard(int token_kind, const std::string &expected_lexeme) {
  std::unique_ptr<Node> next(m_lexer.next());
  if (next->get_tag() != token_kind)
    throw std::runtime_error("Unexpected token (expected '" + expected_lexeme + "', saw '" + next->get_str() + "'");
  // the unique_ptr will delete the token
}

////////////////////////////////////////////////////////////////////////
// Tree printer implementation
////////////////////////////////////////////////////////////////////////

class PrecClimbTreePrint : public TreePrint {
public:
  virtual std::string node_tag_to_string(int tag) const;
};

std::string PrecClimbTreePrint::node_tag_to_string(int tag) const {
  switch (tag) {
  case IDENT: return "IDENT";
  case NUMBER: return "NUMBER";
  case LPAREN: return "LPAREN";
  case RPAREN: return "RPAREN";
  case OP_PLUS: return "OP_PLUS";
  case OP_MINUS: return "OP_MINUS";
  case OP_TIMES: return "OP_TIMES";
  case OP_DIVIDE: return "OP_DIVIDE";
  case OP_EXP: return "OP_EXP";
  case OP_ASSIGN: return "OP_ASSIGN";
  }
  throw std::runtime_error("Unknown tag " + std::to_string(tag));
}

////////////////////////////////////////////////////////////////////////
// main function
////////////////////////////////////////////////////////////////////////

int main() {
  Lexer lexer(std::cin);

#if 0
  while (lexer.peek() != nullptr) {
    Node *tok = lexer.next();
    std::cout << tok->get_tag() << ":" << tok->get_str() << "\n";
    delete tok;
  }
#endif

  Parser parser(lexer);

  Node *tree = parser.parse();

  PrecClimbTreePrint tp;
  tp.print(tree);
  delete tree;
}
