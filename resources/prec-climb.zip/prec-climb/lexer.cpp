#include <iostream>
#include <string>
#include <cctype>
#include <stdexcept>
#include "node.h"
#include "lexer.h"

namespace {

template<typename Pred>
bool match_all(const std::string &s, Pred fn) {
  for (auto i = s.begin(); i != s.end(); ++i) {
    if (!fn(*i))
      return false;
  }
  return true;
}

}


Lexer::Lexer(std::istream &in)
  : m_in(in)
  , m_next(nullptr)
  , m_at_eof(false) {
}

Lexer::~Lexer() {
}

Node *Lexer::peek() {
  fill();
  return m_next;
}

Node *Lexer::next() {
  fill();
  if (m_next == nullptr)
    throw std::runtime_error("Unexpected end of input");
  Node *result = m_next;
  m_next = nullptr;
  return result;
}

void Lexer::fill() {
  if (m_next == nullptr && !m_at_eof) {
    std::string lexeme;

    // Note that by using the istream string extraction operator,
    // we require that all tokens are separated by whitespace.
    // So, for example, "a+b" would be considered a single token.
    if (!(m_in >> lexeme)) {
      m_at_eof = true;
      return;
    }

    m_next = create_token(lexeme);
  }
}

Node *Lexer::create_token(const std::string &lexeme) {
  if (match_all(lexeme, isalpha))
    return new Node(IDENT, lexeme);

  if (match_all(lexeme, isdigit))
    return new Node(NUMBER, lexeme);

  // all other token types are a single character
  if (lexeme.size() != 1)
    throw std::runtime_error("invalid token " + lexeme);

  TokenKind kind;

  switch (lexeme[0]) {
  case '+': kind = OP_PLUS; break;
  case '-': kind = OP_MINUS; break;
  case '*': kind = OP_TIMES; break;
  case '/': kind = OP_DIVIDE; break;
  case '=': kind = OP_ASSIGN; break;
  case '^': kind = OP_EXP; break;
  case '(': kind = LPAREN; break;
  case ')': kind = RPAREN; break;
  default:
    throw std::runtime_error("Invalid token " + lexeme);
  }

  return new Node(kind, lexeme);
}
