#ifndef LEXER_H
#define LEXER_H

#include <iostream>
struct Node;

enum TokenKind {
  IDENT,
  NUMBER,
  LPAREN,
  RPAREN,
  OP_PLUS,
  OP_MINUS,
  OP_TIMES,
  OP_DIVIDE,
  OP_EXP,     // "^" is considered exponentiation
  OP_ASSIGN,
};

class Lexer {
private:
  std::istream &m_in;
  Node *m_next;
  bool m_at_eof;

  Lexer(const Lexer &);
  Lexer &operator=(const Lexer &);

public:
  Lexer(std::istream &in);
  ~Lexer();

  Node *peek();
  Node *next();

private:
  void fill();
  Node *create_token(const std::string &lexeme);
};

#endif // LEXER_H
