This directory is for the linear (code-like) intermediate representation:
Operand, Instruction, InstructionSequence, ControlFlowGraph and friends,
etc.
